import { Card, Container, Row, Col, Image } from "react-bootstrap";
import barbieImage from "../assets/gambar/trending/barbie.jpeg";
import mulanImage from "../assets/gambar/trending/mulan.jpeg";
import noahImage from "../assets/gambar/trending/noah.jpeg";
import pearlImage from "../assets/gambar/trending/pearl.jpeg";
import screamImage from "../assets/gambar/trending/scream.jpeg";
import spidermanImage from "../assets/gambar/trending/spiderman.jpeg";

const Trending = () => {
  return (
    <div>
      <Container>
        <br />
        <br />
        <h1 className="text-white">TRENDING MOVIES</h1>
        <Row>
          <Col md={4} className="movieWrapper" id="trending">
            <Card className="movieImage">
              <Image src={barbieImage} alt="Barbie Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">BARBIE</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={mulanImage} alt="Mulan Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">MULAN</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className=" movieImage">
              <Image src={noahImage} alt="Noah Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">NOAH</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={pearlImage} alt="Pearl Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">PEARL</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={screamImage} alt="Scream Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">SCREAM</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={spidermanImage} alt="Spiderman Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">SPIDERMAN</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Trending;
