import { Card, Container, Row, Col, Image } from "react-bootstrap";
import avengerImage from "../assets/gambar/superhero/avenger.jpeg";
import blackPantherImage from "../assets/gambar/superhero/black panther.jpeg";
import thorImage from "../assets/gambar/superhero/thor.jpeg";
import spidermanImage from "../assets/gambar/superhero/spiderman.jpeg";
import batmanImage from "../assets/gambar/superhero/batman.jpeg";
import supermanImage from "../assets/gambar/superhero/superman.jpeg";

const Superhero = () => {
  return (
    <div>
      <Container>
        <br />
        <br />
        <h1 className="text-white">SUPERHERO MOVIES</h1>
        <Row>
          <Col md={4} className="movieWrapper" id="superhero">
            <Card className="movieImage">
              <Image src={avengerImage} alt="Avenger Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">AVENGER</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={blackPantherImage} alt="Black Panther Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">BLACK PANTHER</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={thorImage} alt="Thor Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">THOR</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={spidermanImage} alt="Spiderman Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">SPIDERMAN</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={batmanImage} alt="Batman Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">BATMAN</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={supermanImage} alt="Superman Movies"  />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
              <Card.Title className="text-center">SUPERMAN</Card.Title>
              <Card.Text className="text-left ">
                This is a wider card with supporting text below as a natural
                lead-in to additional content. This content is a little bit
                longer.
              </Card.Text>
              <Card.Text>Last updated 3 mins ago</Card.Text>
              </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Superhero;
